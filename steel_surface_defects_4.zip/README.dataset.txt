# steel surface defects > 2024-04-19 11:55am
https://universe.roboflow.com/molecular-electronics-research-institute/steel-surface-defects-qqxba

Provided by a Roboflow user
License: CC BY 4.0

